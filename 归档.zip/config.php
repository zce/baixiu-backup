<?php
/**
 * 项目配置文件
 */

/**
 * 数据库主机
 */
define('DB_HOST', '127.0.0.1');

/**
 * 数据库用户名
 */
define('DB_USER', 'root');

/**
 * 数据库密码
 */
define('DB_PASS', 'wanglei');

/**
 * 数据库名称
 */
define('DB_NAME', 'baixiu');
