<?php
/**
 * 配置选项 AJAX
 */

// 如果是 GET 请求，则获取指定配置
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
  if (empty($_GET['key'])) {
    echo 'option key required';
    exit; // 不再往下执行
  }
  exit; // 不再往下执行
}
// 否则是更新配置
